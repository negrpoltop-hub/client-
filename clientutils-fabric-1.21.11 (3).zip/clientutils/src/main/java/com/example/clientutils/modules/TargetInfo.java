package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.NumberSetting;

/** Панель с HP цели и прочностью её брони. Рисуется классом TargetInfoRenderer. */
public class TargetInfo extends Module {
    public final BoolSetting showName = bool("Show name", true);
    public final BoolSetting showHp = bool("Show HP", true);
    public final BoolSetting showBar = bool("Show HP bar", true);
    public final BoolSetting showArmor = bool("Show armor durability", true);
    public final BoolSetting showArmorPoints = bool("Show armor points", true);
    public final BoolSetting crosshair = bool("Use crosshair target", true);
    public final NumberSetting hold = num("Keep after attack (sec)", 5, 1, 30, 1);
    public final NumberSetting corner = num("Position (0TL 1TR 2BL 3BR 4Crosshair)", 4, 0, 4, 1);
    public final NumberSetting offsetX = num("Offset X", 24, 0, 300, 1);
    public final NumberSetting offsetY = num("Offset Y", 4, 0, 300, 1);
    public final BoolSetting background = bool("Background", true);
    public final BoolSetting shadow = bool("Text shadow", true);

    public TargetInfo() { super("Target Info"); }
}
