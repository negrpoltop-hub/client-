package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.NumberSetting;
import com.example.clientutils.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;

/** Кручение при атаке. Крутится взгляд игрока (и камера тоже). */
public class Spin extends Module {
    private final NumberSetting speed = num("Spin speed (deg/tick)", 60, 5, 180, 5);
    private final BoolSetting onlyAttacking = bool("Only when attacking", true);
    private final NumberSetting hold = num("Keep spinning (ticks)", 10, 1, 60, 1);
    private final BoolSetting spinPitch = bool("Spin pitch too", false);
    private float pitchDir = 1f;

    public Spin() { super("Spin"); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;

        if (onlyAttacking.get()) {
            long since = System.currentTimeMillis() - Targets.lastAttackMs;
            if (since > hold.getInt() * 50L) return;
        }

        var p = mc.player;
        p.setYaw(p.getYaw() + (float) speed.get());

        if (spinPitch.get()) {
            float pitch = p.getPitch() + pitchDir * 15f;
            if (pitch > 60f) { pitch = 60f; pitchDir = -1f; }
            if (pitch < -60f) { pitch = -60f; pitchDir = 1f; }
            p.setPitch(MathHelper.clamp(pitch, -90f, 90f));
        }
    }
}
