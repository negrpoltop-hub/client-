package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.NumberSetting;
import com.example.clientutils.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Облёт цели по кругу на заданном радиусе (по умолчанию 5 блоков) с атакой. */
public class Orbit extends Module {
    private final NumberSetting radius = num("Radius", 5.0, 2.0, 8.0, 0.5);
    private final NumberSetting speed = num("Speed (blocks/tick)", 0.8, 0.1, 2.0, 0.1);
    private final NumberSetting height = num("Height offset", 0.0, -3.0, 6.0, 0.5);
    private final BoolSetting clockwise = bool("Clockwise", true);
    private final BoolSetting face = bool("Face target", true);
    private final BoolSetting attack = bool("Auto attack", true);
    private final NumberSetting reach = num("Attack reach", 6.0, 3.0, 8.0, 0.5);
    private final NumberSetting maxDist = num("Max distance", 64, 8, 256, 8);

    public Orbit() { super("Orbit"); }

    private LivingEntity pickTarget(MinecraftClient mc) {
        LivingEntity t = Targets.lastAttacked;
        if (t != null && t.isAlive() && !t.isRemoved() && mc.player.squaredDistanceTo(t) <= maxDist.get() * maxDist.get()) {
            return t;
        }
        return Targets.find(mc, Math.min(maxDist.get(), 32));
    }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;
        LivingEntity t = pickTarget(mc);
        if (t == null) return;

        double r = radius.get();
        double sp = speed.get();

        // Текущий угол игрока вокруг цели и следующая точка на окружности
        double angle = Math.atan2(p.getZ() - t.getZ(), p.getX() - t.getX());
        angle += (clockwise.get() ? 1 : -1) * (sp / r);

        double tx = t.getX() + Math.cos(angle) * r;
        double ty = t.getY() + height.get();
        double tz = t.getZ() + Math.sin(angle) * r;

        double dx = tx - p.getX();
        double dy = ty - p.getY();
        double dz = tz - p.getZ();
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double cap = sp * 1.5;
        if (len > cap) {
            dx = dx / len * cap;
            dy = dy / len * cap;
            dz = dz / len * cap;
        }
        p.setVelocity(dx, dy, dz);

        if (face.get()) {
            Vec3d eye = p.getEyePos();
            Vec3d aim = t.getBoundingBox().getCenter();
            double ax = aim.x - eye.x, ay = aim.y - eye.y, az = aim.z - eye.z;
            p.setYaw((float) (Math.toDegrees(Math.atan2(az, ax)) - 90.0));
            p.setPitch(MathHelper.clamp((float) -Math.toDegrees(Math.atan2(ay, Math.hypot(ax, az))), -90f, 90f));
        }

        if (attack.get() && mc.interactionManager != null && mc.currentScreen == null) {
            double rr = reach.get();
            if (p.squaredDistanceTo(t) <= rr * rr && p.getAttackCooldownProgress(0.5f) >= 1.0f) {
                mc.interactionManager.attackEntity(p, t);
                Targets.onAttack(t);
                p.swingHand(Hand.MAIN_HAND);
            }
        }
    }
}
