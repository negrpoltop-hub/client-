package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.NumberSetting;

/** Оверлей в углу экрана. Выключен по умолчанию (надписей не видно); включается в меню или кнопкой. */
public class HudSettings extends Module {
    public final BoolSetting showTitle = bool("Show title", true);
    public final BoolSetting showModules = bool("Show module list", true);
    public final BoolSetting showCoords = bool("Show coordinates", true);
    public final BoolSetting sortByLength = bool("Sort by length", true);
    public final BoolSetting shadow = bool("Text shadow", true);
    public final NumberSetting corner = num("Corner (0 TL,1 TR,2 BL,3 BR)", 0, 0, 3, 1);
    public final NumberSetting offsetX = num("Offset X", 4, 0, 200, 1);
    public final NumberSetting offsetY = num("Offset Y", 4, 0, 200, 1);
    public final NumberSetting red = num("Color R", 85, 0, 255, 5);
    public final NumberSetting green = num("Color G", 255, 0, 255, 5);
    public final NumberSetting blue = num("Color B", 85, 0, 255, 5);
    public final NumberSetting alpha = num("Opacity %", 100, 20, 100, 5);

    public HudSettings() { super("HUD"); }

    public int color() {
        int a = (int) Math.round(alpha.get() * 2.55);
        return (a << 24) | (red.getInt() << 16) | (green.getInt() << 8) | blue.getInt();
    }

    public int whiteColor() {
        int a = (int) Math.round(alpha.get() * 2.55);
        return (a << 24) | 0xFFFFFF;
    }
}
