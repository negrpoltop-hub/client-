package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.NumberSetting;
import com.example.clientutils.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;

/**
 * Высокий прыжок по кнопке (по умолчанию V) и удар булавой (mace) сверху вниз.
 * Урон булавы растёт с высотой падения.
 */
public class MaceJump extends Module {
    private final NumberSetting jumpHeight = num("Jump height", 25, 5, 60, 1);
    private final NumberSetting upSpeed = num("Up speed", 1.0, 0.3, 2.0, 0.1);
    private final NumberSetting fallSpeed = num("Fall speed", 1.5, 0.5, 3.0, 0.1);
    private final NumberSetting hSpeed = num("Horizontal speed", 1.0, 0.2, 2.0, 0.1);
    private final NumberSetting reach = num("Attack reach", 4.0, 2.0, 6.0, 0.5);
    private final NumberSetting targetRange = num("Target range", 32, 8, 64, 4);
    private final BoolSetting autoSwitch = bool("Auto switch to mace", true);
    private final BoolSetting switchBack = bool("Switch back after", true);

    private enum State { IDLE, ASCEND, FALL }

    private State state = State.IDLE;
    private LivingEntity target;
    private double startY;
    private int ticks;
    private int prevSlot = -1;

    public MaceJump() { super("Mace Jump"); }

    private static void msg(MinecraftClient mc, String text) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(text), true);
    }

    private LivingEntity pickTarget(MinecraftClient mc) {
        double range = targetRange.get();
        LivingEntity t = Targets.lastAttacked;
        if (t != null && t.isAlive() && !t.isRemoved() && mc.player.squaredDistanceTo(t) <= range * range) {
            return t;
        }
        return Targets.find(mc, range);
    }

    /** Вызывается по нажатию кнопки. */
    public void trigger(MinecraftClient mc) {
        if (state != State.IDLE || mc.player == null || mc.world == null) return;
        var p = mc.player;

        LivingEntity t = pickTarget(mc);
        if (t == null) {
            msg(mc, "Mace Jump: нет цели рядом (сначала ударьте цель или включите Target Players)");
            return;
        }

        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(Items.MACE)) { slot = i; break; }
        }
        if (autoSwitch.get()) {
            if (slot < 0) {
                msg(mc, "Mace Jump: нет булавы в хотбаре");
                return;
            }
            prevSlot = p.getInventory().getSelectedSlot();
            p.getInventory().setSelectedSlot(slot);
        } else if (!p.getMainHandStack().isOf(Items.MACE)) {
            msg(mc, "Mace Jump: возьмите булаву в руку");
            return;
        } else {
            prevSlot = -1;
        }

        target = t;
        startY = p.getY();
        ticks = 0;
        state = State.ASCEND;
    }

    private void finish(MinecraftClient mc) {
        state = State.IDLE;
        target = null;
        if (switchBack.get() && prevSlot >= 0 && mc.player != null) {
            mc.player.getInventory().setSelectedSlot(prevSlot);
        }
        prevSlot = -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (state == State.IDLE) return;
        var p = mc.player;

        if (target == null || !target.isAlive() || target.isRemoved()) {
            finish(mc);
            return;
        }

        // Горизонтальное движение к точке над целью
        double dx = target.getX() - p.getX();
        double dz = target.getZ() - p.getZ();
        double hd = Math.hypot(dx, dz);
        double vx = 0, vz = 0;
        if (hd > 0.3) {
            double hs = Math.min(hSpeed.get(), hd);
            vx = dx / hd * hs;
            vz = dz / hd * hs;
        }

        ticks++;

        if (state == State.ASCEND) {
            p.setVelocity(vx, upSpeed.get(), vz);
            if (p.getY() - startY >= jumpHeight.get() || ticks > 300) {
                state = State.FALL;
                ticks = 0;
            }
            return;
        }

        // FALL
        double rr = reach.get();
        if (p.squaredDistanceTo(target) <= rr * rr) {
            if (mc.interactionManager != null && p.getAttackCooldownProgress(0.5f) >= 1.0f) {
                mc.interactionManager.attackEntity(p, target);
                Targets.onAttack(target);
                p.swingHand(Hand.MAIN_HAND);
                finish(mc);
                return;
            }
        }
        p.setVelocity(vx, -fallSpeed.get(), vz);

        if (p.isOnGround() && ticks > 3) {
            finish(mc);
        }
    }
}
