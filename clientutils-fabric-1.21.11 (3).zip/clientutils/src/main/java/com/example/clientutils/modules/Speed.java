package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.ModuleManager;
import com.example.clientutils.NumberSetting;
import com.example.clientutils.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private final NumberSetting mult = num("Multiplier", 1.6, 1.0, 5.0, 0.1);
    private final NumberSetting maxSpeed = num("Max speed", 0.6, 0.2, 2.0, 0.05);
    private final BoolSetting onGround = bool("Only on ground", true);
    private final BoolSetting pauseInFight = bool("Pause in fight", true);
    private final NumberSetting resumeIdle = num("Resume if idle (sec, 0=off)", 0, 0, 60, 1);

    private boolean pausedByFight;
    private LivingEntity fightTarget;

    public Speed() { super("Speed"); }

    /** Вызывается при каждой атаке: выключаем Speed на время драки. */
    public void onFight(LivingEntity target) {
        if (!pauseInFight.get()) return;
        if (isEnabled()) {
            toggle();
            pausedByFight = true;
        }
        if (pausedByFight) {
            fightTarget = target;
        }
    }

    /** Вызывается каждый тик (даже когда Speed выключен): включаем обратно, когда цель убита. */
    public void combatTick(MinecraftClient mc) {
        if (!pausedByFight) return;

        // Пользователь сам включил Speed обратно — больше не управляем
        if (isEnabled()) {
            pausedByFight = false;
            fightTarget = null;
            return;
        }

        boolean killed = fightTarget == null || !fightTarget.isAlive() || fightTarget.isRemoved();
        boolean idle = resumeIdle.get() > 0
                && System.currentTimeMillis() - Targets.lastAttackMs > resumeIdle.get() * 1000.0;

        if (killed || idle) {
            pausedByFight = false;
            fightTarget = null;
            toggle();
        }
    }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;
        boolean moving = p.forwardSpeed != 0 || p.sidewaysSpeed != 0;
        if (!moving) return;
        if (onGround.get() && !p.isOnGround()) return;

        Rage r = ModuleManager.get(Rage.class);
        double boost = r.isEnabled() ? r.boost.get() : 1.0;
        double mul = mult.get() * boost;
        double max = maxSpeed.get() * boost;

        Vec3d v = p.getVelocity();
        double hx = v.x * mul, hz = v.z * mul;
        double len = Math.hypot(hx, hz);
        if (len > max) {
            hx = hx / len * max;
            hz = hz / len * max;
        }
        p.setVelocity(hx, v.y, hz);
    }
}
