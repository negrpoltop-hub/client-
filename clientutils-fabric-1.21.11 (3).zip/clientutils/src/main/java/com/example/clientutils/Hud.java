package com.example.clientutils;

import com.example.clientutils.modules.HudSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Hud {
    private record Line(String text, int color) {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        HudSettings h = ModuleManager.get(HudSettings.class);
        if (!h.isEnabled() || mc.player == null || mc.options.hudHidden) return;

        List<Line> lines = new ArrayList<>();
        int main = h.color();
        int white = h.whiteColor();

        if (h.showTitle.get()) {
            lines.add(new Line("ClientUtils", main));
        }
        if (h.showModules.get()) {
            List<String> names = new ArrayList<>();
            for (Module m : ModuleManager.MODULES) {
                if (m.isEnabled() && !(m instanceof HudSettings)) names.add(m.name);
            }
            if (h.sortByLength.get()) {
                names.sort(Comparator.comparingInt((String s) -> mc.textRenderer.getWidth(s)).reversed());
            }
            for (String n : names) lines.add(new Line(n, main));
        }
        if (h.showCoords.get()) {
            lines.add(new Line(String.format("XYZ: %.1f / %.1f / %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ()), white));
        }
        if (lines.isEmpty()) return;

        int lineH = 10;
        int corner = h.corner.getInt();
        boolean right = corner == 1 || corner == 3;
        boolean bottom = corner == 2 || corner == 3;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int offX = h.offsetX.getInt();
        int offY = h.offsetY.getInt();

        int y = bottom ? sh - offY - lines.size() * lineH : offY;
        for (Line l : lines) {
            int w = mc.textRenderer.getWidth(l.text());
            int x = right ? sw - offX - w : offX;
            ctx.drawText(mc.textRenderer, l.text(), x, y, l.color(), h.shadow.get());
            y += lineH;
        }
    }
}
