package com.example.clientutils;

import com.example.clientutils.modules.TargetInfo;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class TargetInfoRenderer {
    private record Row(String text, int color, double bar) {}

    private static LivingEntity pickTarget(MinecraftClient mc, TargetInfo ti) {
        LivingEntity t = Targets.lastAttacked;
        long since = System.currentTimeMillis() - Targets.lastAttackMs;
        if (t != null && t.isAlive() && !t.isRemoved() && since < ti.hold.get() * 1000.0) return t;

        t = Targets.locked;
        if (t != null && t.isAlive() && !t.isRemoved()) return t;

        if (ti.crosshair.get() && mc.targetedEntity instanceof LivingEntity le && le.isAlive()) return le;
        return null;
    }

    private static int pctColor(double ratio) {
        if (ratio > 0.6) return 0xFF55FF55;
        if (ratio > 0.3) return 0xFFFFFF55;
        return 0xFFFF5555;
    }

    private static void armorRow(List<Row> rows, LivingEntity t, EquipmentSlot slot, String label) {
        ItemStack st = t.getEquippedStack(slot);
        if (st.isEmpty()) {
            rows.add(new Row(label + ": -", 0xFFAAAAAA, -1));
        } else if (st.isDamageable()) {
            int max = st.getMaxDamage();
            int left = max - st.getDamage();
            double ratio = max <= 0 ? 1.0 : (double) left / max;
            rows.add(new Row(String.format("%s: %d/%d (%d%%)", label, left, max, Math.round(ratio * 100)),
                    pctColor(ratio), -1));
        } else {
            rows.add(new Row(label + ": ok", 0xFFFFFFFF, -1));
        }
    }

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TargetInfo ti = ModuleManager.get(TargetInfo.class);
        if (!ti.isEnabled() || mc.player == null || mc.world == null || mc.options.hudHidden) return;

        LivingEntity t = pickTarget(mc, ti);
        if (t == null) return;

        List<Row> rows = new ArrayList<>();
        if (ti.showName.get()) {
            rows.add(new Row(t.getName().getString(), 0xFFFFFFFF, -1));
        }

        float hp = t.getHealth();
        float maxHp = t.getMaxHealth();
        double ratio = maxHp <= 0 ? 0 : Math.max(0, Math.min(1.0, hp / maxHp));
        if (ti.showHp.get()) {
            float abs = t.getAbsorptionAmount();
            String s = String.format("HP: %.1f / %.1f", hp, maxHp);
            if (abs > 0) s += String.format(" (+%.1f)", abs);
            rows.add(new Row(s, pctColor(ratio), -1));
        }
        if (ti.showBar.get()) {
            rows.add(new Row("", pctColor(ratio), ratio));
        }

        if (ti.showArmor.get()) {
            boolean any = false;
            for (EquipmentSlot s : new EquipmentSlot[] {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                if (!t.getEquippedStack(s).isEmpty()) any = true;
            }
            if (any || t instanceof PlayerEntity) {
                armorRow(rows, t, EquipmentSlot.HEAD, "Helmet");
                armorRow(rows, t, EquipmentSlot.CHEST, "Chest");
                armorRow(rows, t, EquipmentSlot.LEGS, "Legs");
                armorRow(rows, t, EquipmentSlot.FEET, "Boots");
            }
        }
        if (ti.showArmorPoints.get()) {
            rows.add(new Row("Armor points: " + t.getArmor(), 0xFF9FD0FF, -1));
        }
        if (rows.isEmpty()) return;

        // Размеры панели
        int w = 100;
        int h = 0;
        for (Row r : rows) {
            if (r.bar() >= 0) {
                h += 8;
            } else {
                w = Math.max(w, mc.textRenderer.getWidth(r.text()));
                h += 10;
            }
        }

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int offX = ti.offsetX.getInt();
        int offY = ti.offsetY.getInt();
        int corner = ti.corner.getInt();
        int x, y;
        switch (corner) {
            case 1 -> { x = sw - offX - w; y = offY; }
            case 2 -> { x = offX; y = sh - offY - h; }
            case 3 -> { x = sw - offX - w; y = sh - offY - h; }
            case 4 -> { x = sw / 2 + offX; y = sh / 2 - h / 2 + offY - 4; }
            default -> { x = offX; y = offY; }
        }

        if (ti.background.get()) {
            ctx.fill(x - 3, y - 3, x + w + 3, y + h + 3, 0x80000000);
        }

        int cy = y;
        for (Row r : rows) {
            if (r.bar() >= 0) {
                ctx.fill(x, cy + 1, x + w, cy + 6, 0xFF333333);
                ctx.fill(x, cy + 1, x + (int) Math.round(w * r.bar()), cy + 6, r.color());
                cy += 8;
            } else {
                ctx.drawText(mc.textRenderer, r.text(), x, cy, r.color(), ti.shadow.get());
                cy += 10;
            }
        }
    }
}
