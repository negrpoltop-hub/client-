# ClientUtils (Fabric 1.21.11)
Клиентский мод: Fly, Speed, ESP, Fullbright, AutoSprint, KillAura, Aimbot, Auto Target, Follow Fly, Rage + HUD + GUI.

Сборка: `gradle wrapper` (один раз), затем `./gradlew build` -> build/libs/clientutils-1.0.0.jar
Запуск для теста: `./gradlew runClient`
Меню: Ctrl+Shift+I (колёсико мыши прокручивает список; кнопка ">" открывает настройки модуля; настройки сохраняются в config/clientutils.properties). Полёт: G. Rage-режим: R. Высокий прыжок с булавой: V. Target Info (HP и броня цели) включён по умолчанию. HUD скрыт по умолчанию (включается в меню, модуль HUD; клавишу можно назначить в управлении).

Версии в gradle.properties сверь на https://fabricmc.net/develop
Используй в одиночной игре или на своих серверах: на публичных серверах такие функции банятся.
